﻿namespace AngelBot
{
    partial class settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(settings));
            this.btnsave = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.tabBinding = new System.Windows.Forms.TabPage();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.txtheal = new System.Windows.Forms.TextBox();
            this.txtautoattack = new System.Windows.Forms.TextBox();
            this.txtmppot = new System.Windows.Forms.TextBox();
            this.txthppot = new System.Windows.Forms.TextBox();
            this.txtself = new System.Windows.Forms.TextBox();
            this.txtturn = new System.Windows.Forms.TextBox();
            this.txttarget = new System.Windows.Forms.TextBox();
            this.txtrest = new System.Windows.Forms.TextBox();
            this.txtloot = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tabBuffs = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.tabHealing = new System.Windows.Forms.TabPage();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.tabAttacks = new System.Windows.Forms.TabPage();
            this.button12 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPreAttacks = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabCharacter = new System.Windows.Forms.TabPage();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabLimits = new System.Windows.Forms.TabPage();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.txtooc = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabBinding.SuspendLayout();
            this.tabBuffs.SuspendLayout();
            this.tabHealing.SuspendLayout();
            this.tabAttacks.SuspendLayout();
            this.tabPreAttacks.SuspendLayout();
            this.tabCharacter.SuspendLayout();
            this.tabLimits.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(40, 294);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 1;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(134, 294);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 2;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // tabBinding
            // 
            this.tabBinding.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabBinding.Controls.Add(this.textBox31);
            this.tabBinding.Controls.Add(this.textBox23);
            this.tabBinding.Controls.Add(this.textBox24);
            this.tabBinding.Controls.Add(this.textBox16);
            this.tabBinding.Controls.Add(this.txtheal);
            this.tabBinding.Controls.Add(this.txtautoattack);
            this.tabBinding.Controls.Add(this.txtmppot);
            this.tabBinding.Controls.Add(this.txthppot);
            this.tabBinding.Controls.Add(this.txtself);
            this.tabBinding.Controls.Add(this.txtturn);
            this.tabBinding.Controls.Add(this.txttarget);
            this.tabBinding.Controls.Add(this.txtrest);
            this.tabBinding.Controls.Add(this.txtloot);
            this.tabBinding.Controls.Add(this.label62);
            this.tabBinding.Controls.Add(this.label53);
            this.tabBinding.Controls.Add(this.label54);
            this.tabBinding.Controls.Add(this.label43);
            this.tabBinding.Controls.Add(this.label39);
            this.tabBinding.Controls.Add(this.label38);
            this.tabBinding.Controls.Add(this.label37);
            this.tabBinding.Controls.Add(this.label36);
            this.tabBinding.Controls.Add(this.label35);
            this.tabBinding.Controls.Add(this.label31);
            this.tabBinding.Controls.Add(this.label32);
            this.tabBinding.Controls.Add(this.label33);
            this.tabBinding.Controls.Add(this.label34);
            this.tabBinding.Location = new System.Drawing.Point(4, 22);
            this.tabBinding.Name = "tabBinding";
            this.tabBinding.Size = new System.Drawing.Size(450, 259);
            this.tabBinding.TabIndex = 5;
            this.tabBinding.Text = "KeyBinding";
            this.tabBinding.UseVisualStyleBackColor = true;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(349, 92);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(31, 20);
            this.textBox31.TabIndex = 43;
            this.textBox31.Text = "=";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(349, 69);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(31, 20);
            this.textBox23.TabIndex = 41;
            this.textBox23.Text = "e";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(349, 43);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(31, 20);
            this.textBox24.TabIndex = 39;
            this.textBox24.Text = "q";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(349, 17);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(31, 20);
            this.textBox16.TabIndex = 37;
            this.textBox16.Text = "Alt,9";
            // 
            // txtheal
            // 
            this.txtheal.Enabled = false;
            this.txtheal.Location = new System.Drawing.Point(162, 210);
            this.txtheal.Name = "txtheal";
            this.txtheal.Size = new System.Drawing.Size(31, 20);
            this.txtheal.TabIndex = 35;
            this.txtheal.Text = "Alt,6";
            // 
            // txtautoattack
            // 
            this.txtautoattack.Location = new System.Drawing.Point(162, 187);
            this.txtautoattack.Name = "txtautoattack";
            this.txtautoattack.Size = new System.Drawing.Size(31, 20);
            this.txtautoattack.TabIndex = 33;
            this.txtautoattack.Text = "c";
            // 
            // txtmppot
            // 
            this.txtmppot.Location = new System.Drawing.Point(162, 164);
            this.txtmppot.Name = "txtmppot";
            this.txtmppot.Size = new System.Drawing.Size(31, 20);
            this.txtmppot.TabIndex = 31;
            this.txtmppot.Text = "Alt,4";
            // 
            // txthppot
            // 
            this.txthppot.Location = new System.Drawing.Point(162, 138);
            this.txthppot.Name = "txthppot";
            this.txthppot.Size = new System.Drawing.Size(31, 20);
            this.txthppot.TabIndex = 29;
            this.txthppot.Text = "Alt,3";
            // 
            // txtself
            // 
            this.txtself.Enabled = false;
            this.txtself.Location = new System.Drawing.Point(162, 112);
            this.txtself.Name = "txtself";
            this.txtself.Size = new System.Drawing.Size(31, 20);
            this.txtself.TabIndex = 27;
            this.txtself.Text = "F1";
            // 
            // txtturn
            // 
            this.txtturn.Enabled = false;
            this.txtturn.Location = new System.Drawing.Point(162, 89);
            this.txtturn.Name = "txtturn";
            this.txtturn.Size = new System.Drawing.Size(31, 20);
            this.txtturn.TabIndex = 25;
            this.txtturn.Text = "z";
            // 
            // txttarget
            // 
            this.txttarget.Location = new System.Drawing.Point(162, 65);
            this.txttarget.Name = "txttarget";
            this.txttarget.Size = new System.Drawing.Size(31, 20);
            this.txttarget.TabIndex = 24;
            this.txttarget.Text = "TAB";
            // 
            // txtrest
            // 
            this.txtrest.Location = new System.Drawing.Point(162, 43);
            this.txtrest.Name = "txtrest";
            this.txtrest.Size = new System.Drawing.Size(31, 20);
            this.txtrest.TabIndex = 23;
            this.txtrest.Text = ",";
            // 
            // txtloot
            // 
            this.txtloot.Location = new System.Drawing.Point(162, 17);
            this.txtloot.Name = "txtloot";
            this.txtloot.Size = new System.Drawing.Size(31, 20);
            this.txtloot.TabIndex = 22;
            this.txtloot.Text = "-";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(280, 95);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(59, 13);
            this.label62.TabIndex = 42;
            this.label62.Text = "Return key";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(280, 72);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(63, 13);
            this.label53.TabIndex = 40;
            this.label53.Text = "Strafe Right";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(286, 46);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(56, 13);
            this.label54.TabIndex = 38;
            this.label54.Text = "Strafe Left";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(288, 20);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(55, 13);
            this.label43.TabIndex = 36;
            this.label43.Text = "OOC Heal";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(127, 213);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 13);
            this.label39.TabIndex = 34;
            this.label39.Text = "Heal";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(35, 190);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(121, 13);
            this.label38.TabIndex = 32;
            this.label38.Text = "Get in range/autoattack";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(103, 164);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 13);
            this.label37.TabIndex = 30;
            this.label37.Text = "Mana Pot";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(99, 141);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(57, 13);
            this.label36.TabIndex = 28;
            this.label36.Text = "Health Pot";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(101, 115);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(56, 13);
            this.label35.TabIndex = 26;
            this.label35.Text = "SelfTarget";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(93, 92);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 13);
            this.label31.TabIndex = 21;
            this.label31.Text = "TurnAround";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(84, 68);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 13);
            this.label32.TabIndex = 20;
            this.label32.Text = "Target Button";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(94, 46);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(63, 13);
            this.label33.TabIndex = 19;
            this.label33.Text = "Rest Button";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(94, 20);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(62, 13);
            this.label34.TabIndex = 18;
            this.label34.Text = "Loot Button";
            // 
            // tabBuffs
            // 
            this.tabBuffs.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabBuffs.Controls.Add(this.button13);
            this.tabBuffs.Controls.Add(this.label27);
            this.tabBuffs.Controls.Add(this.label28);
            this.tabBuffs.Controls.Add(this.label29);
            this.tabBuffs.Controls.Add(this.label30);
            this.tabBuffs.Controls.Add(this.button14);
            this.tabBuffs.Controls.Add(this.button15);
            this.tabBuffs.Controls.Add(this.button16);
            this.tabBuffs.Controls.Add(this.button17);
            this.tabBuffs.Controls.Add(this.button18);
            this.tabBuffs.Controls.Add(this.textBox14);
            this.tabBuffs.Controls.Add(this.textBox15);
            this.tabBuffs.Controls.Add(this.listBox3);
            this.tabBuffs.Location = new System.Drawing.Point(4, 22);
            this.tabBuffs.Name = "tabBuffs";
            this.tabBuffs.Size = new System.Drawing.Size(450, 259);
            this.tabBuffs.TabIndex = 4;
            this.tabBuffs.Text = "Buffs";
            this.tabBuffs.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Enabled = false;
            this.button13.Location = new System.Drawing.Point(47, 197);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(101, 23);
            this.button13.TabIndex = 39;
            this.button13.Text = "Edit Selected";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 124);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(98, 13);
            this.label27.TabIndex = 38;
            this.label27.Text = "(Example: .5 or 3.2)";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 102);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(134, 13);
            this.label28.TabIndex = 37;
            this.label28.Text = "Recast after execute (min):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 50);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(101, 13);
            this.label29.TabIndex = 36;
            this.label29.Text = "(Example: 1 or Alt,4)";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 13);
            this.label30.TabIndex = 35;
            this.label30.Text = "Enter Buff Button:";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(212, 226);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(100, 23);
            this.button14.TabIndex = 34;
            this.button14.Text = "Clear List";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(212, 197);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(100, 23);
            this.button15.TabIndex = 33;
            this.button15.Text = "Move Down";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(212, 166);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(100, 25);
            this.button16.TabIndex = 32;
            this.button16.Text = "Move Up";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(47, 226);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(101, 23);
            this.button17.TabIndex = 31;
            this.button17.Text = "Remove Selected";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(47, 169);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(101, 23);
            this.button18.TabIndex = 30;
            this.button18.Text = "Add to Queue";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(13, 66);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(165, 20);
            this.textBox14.TabIndex = 28;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(13, 143);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(165, 20);
            this.textBox15.TabIndex = 29;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(184, 3);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(139, 160);
            this.listBox3.TabIndex = 27;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // tabHealing
            // 
            this.tabHealing.Controls.Add(this.label59);
            this.tabHealing.Controls.Add(this.label60);
            this.tabHealing.Controls.Add(this.textBox30);
            this.tabHealing.Controls.Add(this.textBox28);
            this.tabHealing.Controls.Add(this.textBox27);
            this.tabHealing.Controls.Add(this.textBox29);
            this.tabHealing.Controls.Add(this.label64);
            this.tabHealing.Controls.Add(this.label65);
            this.tabHealing.Controls.Add(this.button22);
            this.tabHealing.Controls.Add(this.label61);
            this.tabHealing.Controls.Add(this.label63);
            this.tabHealing.Controls.Add(this.button26);
            this.tabHealing.Controls.Add(this.button25);
            this.tabHealing.Controls.Add(this.button24);
            this.tabHealing.Controls.Add(this.button23);
            this.tabHealing.Controls.Add(this.button21);
            this.tabHealing.Controls.Add(this.listBox5);
            this.tabHealing.Location = new System.Drawing.Point(4, 22);
            this.tabHealing.Name = "tabHealing";
            this.tabHealing.Size = new System.Drawing.Size(450, 259);
            this.tabHealing.TabIndex = 7;
            this.tabHealing.Text = "Healing";
            this.tabHealing.UseVisualStyleBackColor = true;
            // 
            // label59
            // 
            this.label59.Location = new System.Drawing.Point(339, 7);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(107, 188);
            this.label59.TabIndex = 60;
            this.label59.Text = resources.GetString("label59.Text");
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(20, 95);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(152, 13);
            this.label60.TabIndex = 59;
            this.label60.Text = "Enter Casting Time in Seconds";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(23, 149);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(165, 20);
            this.textBox30.TabIndex = 45;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(23, 71);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(165, 20);
            this.textBox28.TabIndex = 43;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(23, 18);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(165, 20);
            this.textBox27.TabIndex = 42;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(23, 111);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(165, 20);
            this.textBox29.TabIndex = 44;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(20, 56);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(98, 13);
            this.label64.TabIndex = 57;
            this.label64.Text = "(Example: 25 or 75)";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(20, 42);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(145, 13);
            this.label65.TabIndex = 56;
            this.label65.Text = "Enter Health Percentage Left";
            // 
            // button22
            // 
            this.button22.Enabled = false;
            this.button22.Location = new System.Drawing.Point(57, 200);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(101, 23);
            this.button22.TabIndex = 47;
            this.button22.Text = "Edit Selected";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(20, 134);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(138, 13);
            this.label61.TabIndex = 51;
            this.label61.Text = "Enter Cooldown in Seconds";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(20, 3);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(108, 13);
            this.label63.TabIndex = 49;
            this.label63.Text = "Enter Healing Hotkey";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(222, 229);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(100, 23);
            this.button26.TabIndex = 51;
            this.button26.Text = "Clear List";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(222, 200);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(100, 23);
            this.button25.TabIndex = 50;
            this.button25.Text = "Move Down";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(222, 169);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(100, 25);
            this.button24.TabIndex = 49;
            this.button24.Text = "Move Up";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(57, 229);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(101, 23);
            this.button23.TabIndex = 48;
            this.button23.Text = "Remove Selected";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(57, 172);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(101, 23);
            this.button21.TabIndex = 46;
            this.button21.Text = "Add to Queue";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(194, 6);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(139, 160);
            this.listBox5.TabIndex = 41;
            this.listBox5.SelectedIndexChanged += new System.EventHandler(this.listBox5_SelectedIndexChanged);
            // 
            // tabAttacks
            // 
            this.tabAttacks.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabAttacks.Controls.Add(this.button12);
            this.tabAttacks.Controls.Add(this.label21);
            this.tabAttacks.Controls.Add(this.label22);
            this.tabAttacks.Controls.Add(this.label23);
            this.tabAttacks.Controls.Add(this.label24);
            this.tabAttacks.Controls.Add(this.label25);
            this.tabAttacks.Controls.Add(this.button6);
            this.tabAttacks.Controls.Add(this.button7);
            this.tabAttacks.Controls.Add(this.button8);
            this.tabAttacks.Controls.Add(this.button9);
            this.tabAttacks.Controls.Add(this.button10);
            this.tabAttacks.Controls.Add(this.textBox11);
            this.tabAttacks.Controls.Add(this.textBox12);
            this.tabAttacks.Controls.Add(this.listBox2);
            this.tabAttacks.Location = new System.Drawing.Point(4, 22);
            this.tabAttacks.Name = "tabAttacks";
            this.tabAttacks.Size = new System.Drawing.Size(450, 259);
            this.tabAttacks.TabIndex = 3;
            this.tabAttacks.Text = "Attacks";
            this.tabAttacks.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Enabled = false;
            this.button12.Location = new System.Drawing.Point(44, 201);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(101, 23);
            this.button12.TabIndex = 26;
            this.button12.Text = "Edit Selected";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label21
            // 
            this.label21.Enabled = false;
            this.label21.Location = new System.Drawing.Point(336, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(107, 101);
            this.label21.TabIndex = 25;
            this.label21.Text = "Attacks are a sequence that rotates until target is dead.";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Enabled = false;
            this.label22.Location = new System.Drawing.Point(7, 128);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(98, 13);
            this.label22.TabIndex = 24;
            this.label22.Text = "(Example: .5 or 3.2)";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Enabled = false;
            this.label23.Location = new System.Drawing.Point(7, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 13);
            this.label23.TabIndex = 23;
            this.label23.Text = "Cast Time (sec):";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Enabled = false;
            this.label24.Location = new System.Drawing.Point(7, 54);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(101, 13);
            this.label24.TabIndex = 22;
            this.label24.Text = "(Example: 1 or Alt,4)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Enabled = false;
            this.label25.Location = new System.Drawing.Point(7, 31);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 13);
            this.label25.TabIndex = 21;
            this.label25.Text = "Enter Attack Button:";
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(209, 230);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 23);
            this.button6.TabIndex = 20;
            this.button6.Text = "Clear List";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(209, 201);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 23);
            this.button7.TabIndex = 19;
            this.button7.Text = "Move Down";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(209, 170);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(100, 25);
            this.button8.TabIndex = 18;
            this.button8.Text = "Move Up";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(44, 230);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 23);
            this.button9.TabIndex = 17;
            this.button9.Text = "Remove Selected";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.Location = new System.Drawing.Point(44, 173);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(101, 23);
            this.button10.TabIndex = 14;
            this.button10.Text = "Add to Queue";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // textBox11
            // 
            this.textBox11.Enabled = false;
            this.textBox11.Location = new System.Drawing.Point(10, 70);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(165, 20);
            this.textBox11.TabIndex = 15;
            // 
            // textBox12
            // 
            this.textBox12.Enabled = false;
            this.textBox12.Location = new System.Drawing.Point(10, 147);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(165, 20);
            this.textBox12.TabIndex = 16;
            // 
            // listBox2
            // 
            this.listBox2.Enabled = false;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(181, 7);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(139, 160);
            this.listBox2.TabIndex = 13;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // tabPreAttacks
            // 
            this.tabPreAttacks.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPreAttacks.Controls.Add(this.button11);
            this.tabPreAttacks.Controls.Add(this.label20);
            this.tabPreAttacks.Controls.Add(this.label19);
            this.tabPreAttacks.Controls.Add(this.label18);
            this.tabPreAttacks.Controls.Add(this.label17);
            this.tabPreAttacks.Controls.Add(this.label16);
            this.tabPreAttacks.Controls.Add(this.button5);
            this.tabPreAttacks.Controls.Add(this.button4);
            this.tabPreAttacks.Controls.Add(this.button3);
            this.tabPreAttacks.Controls.Add(this.button2);
            this.tabPreAttacks.Controls.Add(this.button1);
            this.tabPreAttacks.Controls.Add(this.textBox10);
            this.tabPreAttacks.Controls.Add(this.textBox9);
            this.tabPreAttacks.Controls.Add(this.listBox1);
            this.tabPreAttacks.Location = new System.Drawing.Point(4, 22);
            this.tabPreAttacks.Name = "tabPreAttacks";
            this.tabPreAttacks.Size = new System.Drawing.Size(450, 259);
            this.tabPreAttacks.TabIndex = 2;
            this.tabPreAttacks.Text = "Pre-Attacks";
            this.tabPreAttacks.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Enabled = false;
            this.button11.Location = new System.Drawing.Point(48, 196);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 23);
            this.button11.TabIndex = 13;
            this.button11.Text = "Edit Selected";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label20
            // 
            this.label20.Enabled = false;
            this.label20.Location = new System.Drawing.Point(340, 14);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 101);
            this.label20.TabIndex = 12;
            this.label20.Text = "Pre-attacks are a sequence executed before normal attack rotation.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Enabled = false;
            this.label19.Location = new System.Drawing.Point(11, 111);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(98, 13);
            this.label19.TabIndex = 11;
            this.label19.Text = "(Example: .5 or 3.2)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Enabled = false;
            this.label18.Location = new System.Drawing.Point(11, 89);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 13);
            this.label18.TabIndex = 10;
            this.label18.Text = "Cast Time (sec):";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Enabled = false;
            this.label17.Location = new System.Drawing.Point(11, 37);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "(Example: 1 or Alt,4)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Enabled = false;
            this.label16.Location = new System.Drawing.Point(11, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(121, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Enter Pre-attack Button:";
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(213, 225);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 23);
            this.button5.TabIndex = 7;
            this.button5.Text = "Clear List";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(213, 196);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Move Down";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(213, 165);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 25);
            this.button3.TabIndex = 5;
            this.button3.Text = "Move Up";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(48, 225);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Remove Selected";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(48, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Add to Queue";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox10
            // 
            this.textBox10.Enabled = false;
            this.textBox10.Location = new System.Drawing.Point(14, 127);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(165, 20);
            this.textBox10.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.Enabled = false;
            this.textBox9.Location = new System.Drawing.Point(14, 53);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(165, 20);
            this.textBox9.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.Enabled = false;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(185, 3);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(139, 160);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tabCharacter
            // 
            this.tabCharacter.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabCharacter.Controls.Add(this.checkBox6);
            this.tabCharacter.Controls.Add(this.checkBox5);
            this.tabCharacter.Controls.Add(this.checkBox4);
            this.tabCharacter.Controls.Add(this.label48);
            this.tabCharacter.Controls.Add(this.textBox19);
            this.tabCharacter.Controls.Add(this.textBox13);
            this.tabCharacter.Controls.Add(this.textBox8);
            this.tabCharacter.Controls.Add(this.label49);
            this.tabCharacter.Controls.Add(this.checkBox3);
            this.tabCharacter.Controls.Add(this.label26);
            this.tabCharacter.Controls.Add(this.label15);
            this.tabCharacter.Controls.Add(this.label14);
            this.tabCharacter.Controls.Add(this.checkBox2);
            this.tabCharacter.Controls.Add(this.checkBox1);
            this.tabCharacter.Location = new System.Drawing.Point(4, 22);
            this.tabCharacter.Name = "tabCharacter";
            this.tabCharacter.Padding = new System.Windows.Forms.Padding(3);
            this.tabCharacter.Size = new System.Drawing.Size(450, 259);
            this.tabCharacter.TabIndex = 1;
            this.tabCharacter.Text = "Character";
            this.tabCharacter.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.Location = new System.Drawing.Point(30, 112);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(122, 24);
            this.checkBox6.TabIndex = 0;
            this.checkBox6.Text = "Use Kisk/SelfRes";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(24, 181);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(64, 17);
            this.checkBox5.TabIndex = 13;
            this.checkBox5.Text = "Logging";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(29, 90);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(123, 17);
            this.checkBox4.TabIndex = 12;
            this.checkBox4.Text = "Full Inventory Check";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(140, 145);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(20, 13);
            this.label48.TabIndex = 11;
            this.label48.Text = "ms";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(89, 142);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(45, 20);
            this.textBox19.TabIndex = 10;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(24, 217);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(32, 20);
            this.textBox13.TabIndex = 7;
            this.textBox13.Text = "100";
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(239, 41);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(34, 20);
            this.textBox8.TabIndex = 3;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(22, 145);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(61, 13);
            this.label49.TabIndex = 9;
            this.label49.Text = "Loot Delay:";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(29, 67);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(162, 17);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "Enable Anti-stuck for combat";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(21, 201);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 13);
            this.label26.TabIndex = 6;
            this.label26.Text = "Transparency %";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(279, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Ft";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(110, 45);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Range before pre-attack:";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(29, 44);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(64, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Ranged";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(29, 20);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(57, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Healer";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tabLimits
            // 
            this.tabLimits.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabLimits.Controls.Add(this.label57);
            this.tabLimits.Controls.Add(this.textBox26);
            this.tabLimits.Controls.Add(this.textBox25);
            this.tabLimits.Controls.Add(this.txtooc);
            this.tabLimits.Controls.Add(this.textBox7);
            this.tabLimits.Controls.Add(this.textBox6);
            this.tabLimits.Controls.Add(this.textBox5);
            this.tabLimits.Controls.Add(this.textBox4);
            this.tabLimits.Controls.Add(this.textBox2);
            this.tabLimits.Controls.Add(this.textBox1);
            this.tabLimits.Controls.Add(this.label58);
            this.tabLimits.Controls.Add(this.label55);
            this.tabLimits.Controls.Add(this.label56);
            this.tabLimits.Controls.Add(this.groupBox1);
            this.tabLimits.Controls.Add(this.comboBox1);
            this.tabLimits.Controls.Add(this.label41);
            this.tabLimits.Controls.Add(this.label42);
            this.tabLimits.Controls.Add(this.label13);
            this.tabLimits.Controls.Add(this.label12);
            this.tabLimits.Controls.Add(this.label11);
            this.tabLimits.Controls.Add(this.label10);
            this.tabLimits.Controls.Add(this.label8);
            this.tabLimits.Controls.Add(this.label7);
            this.tabLimits.Controls.Add(this.label6);
            this.tabLimits.Controls.Add(this.label5);
            this.tabLimits.Controls.Add(this.label4);
            this.tabLimits.Controls.Add(this.label2);
            this.tabLimits.Controls.Add(this.label1);
            this.tabLimits.Location = new System.Drawing.Point(4, 22);
            this.tabLimits.Name = "tabLimits";
            this.tabLimits.Padding = new System.Windows.Forms.Padding(3);
            this.tabLimits.Size = new System.Drawing.Size(450, 259);
            this.tabLimits.TabIndex = 0;
            this.tabLimits.Text = "Limits";
            this.tabLimits.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(136, 221);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(27, 13);
            this.label57.TabIndex = 40;
            this.label57.Text = "sec.";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(99, 218);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(39, 20);
            this.textBox26.TabIndex = 39;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(99, 194);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(31, 20);
            this.textBox25.TabIndex = 36;
            // 
            // txtooc
            // 
            this.txtooc.Location = new System.Drawing.Point(157, 170);
            this.txtooc.Name = "txtooc";
            this.txtooc.Size = new System.Drawing.Size(31, 20);
            this.txtooc.TabIndex = 28;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(99, 143);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(31, 20);
            this.textBox7.TabIndex = 20;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(99, 118);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(31, 20);
            this.textBox6.TabIndex = 19;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(99, 95);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(31, 20);
            this.textBox5.TabIndex = 18;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(99, 71);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(31, 20);
            this.textBox4.TabIndex = 17;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(99, 45);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(31, 20);
            this.textBox2.TabIndex = 15;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(99, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(31, 20);
            this.textBox1.TabIndex = 14;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(6, 221);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(90, 13);
            this.label58.TabIndex = 38;
            this.label58.Text = "Death Rest Timer";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(136, 197);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(26, 13);
            this.label55.TabIndex = 37;
            this.label55.Text = "min.";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(28, 197);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(60, 13);
            this.label56.TabIndex = 35;
            this.label56.Text = "Bot Shutoff";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.textBox18);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox17);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Location = new System.Drawing.Point(197, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(172, 103);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Heals";
            this.groupBox1.Visible = false;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(121, 69);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 13);
            this.label46.TabIndex = 36;
            this.label46.Text = "sec";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(84, 66);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(31, 20);
            this.textBox18.TabIndex = 35;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 69);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(79, 13);
            this.label47.TabIndex = 34;
            this.label47.Text = "Heal Cooldown";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Heal HP";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(121, 45);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(24, 13);
            this.label45.TabIndex = 33;
            this.label45.Text = "sec";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(84, 19);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(31, 20);
            this.textBox3.TabIndex = 16;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(84, 42);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(31, 20);
            this.textBox17.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(121, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "%";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 45);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(59, 13);
            this.label44.TabIndex = 31;
            this.label44.Text = "Heal Delay";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Heal",
            "Mana"});
            this.comboBox1.Location = new System.Drawing.Point(94, 169);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(57, 21);
            this.comboBox1.TabIndex = 30;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(194, 172);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(15, 13);
            this.label41.TabIndex = 29;
            this.label41.Text = "%";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(13, 172);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 13);
            this.label42.TabIndex = 27;
            this.label42.Text = "Out of Combat";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(136, 146);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "min.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(136, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(136, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "%";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(136, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "%";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(136, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "%";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Ignore Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Ignore Level";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Potion MP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Potion HP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Resting Mana";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Resting HP";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabLimits);
            this.tabControl1.Controls.Add(this.tabCharacter);
            this.tabControl1.Controls.Add(this.tabPreAttacks);
            this.tabControl1.Controls.Add(this.tabAttacks);
            this.tabControl1.Controls.Add(this.tabHealing);
            this.tabControl1.Controls.Add(this.tabBuffs);
            this.tabControl1.Controls.Add(this.tabBinding);
            this.tabControl1.Location = new System.Drawing.Point(12, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(458, 285);
            this.tabControl1.TabIndex = 0;
            // 
            // settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 323);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.settings_Load);
            this.tabBinding.ResumeLayout(false);
            this.tabBinding.PerformLayout();
            this.tabBuffs.ResumeLayout(false);
            this.tabBuffs.PerformLayout();
            this.tabHealing.ResumeLayout(false);
            this.tabHealing.PerformLayout();
            this.tabAttacks.ResumeLayout(false);
            this.tabAttacks.PerformLayout();
            this.tabPreAttacks.ResumeLayout(false);
            this.tabPreAttacks.PerformLayout();
            this.tabCharacter.ResumeLayout(false);
            this.tabCharacter.PerformLayout();
            this.tabLimits.ResumeLayout(false);
            this.tabLimits.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.TabPage tabBinding;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox txtheal;
        private System.Windows.Forms.TextBox txtautoattack;
        private System.Windows.Forms.TextBox txtmppot;
        private System.Windows.Forms.TextBox txthppot;
        private System.Windows.Forms.TextBox txtself;
        private System.Windows.Forms.TextBox txtturn;
        private System.Windows.Forms.TextBox txttarget;
        private System.Windows.Forms.TextBox txtrest;
        private System.Windows.Forms.TextBox txtloot;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TabPage tabBuffs;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.TabPage tabHealing;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.TabPage tabAttacks;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TabPage tabPreAttacks;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TabPage tabCharacter;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TabPage tabLimits;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox txtooc;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.CheckBox checkBox6;
    }
}